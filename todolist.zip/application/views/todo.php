<!-- START NAVBAR ==========-->
<?php $this->load->view("includes/header"); ?>
<!--========== END NAVBAR -->
<body style="margin-top: 10px">
<div class="container">
    <!-- START NAVBAR ==========-->
    <?php $this->load->view("includes/navbar"); ?>
    <!--========== END NAVBAR -->
    <br>
    <!-- START CONTENT ==========-->
    <?php $this->load->view("todo_v/content"); ?>
    <!--========== END CONTENT -->
</div>
<!-- START MODAL ==========-->
<?php $this->load->view("includes/modal"); ?>
<!--========== END MODAL -->
<!-- START scripts ==========-->
<?php $this->load->view("includes/footer"); ?>
<!--========== END scripts -->

